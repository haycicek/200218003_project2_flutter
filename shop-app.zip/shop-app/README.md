HAMZA SÖĞÜT 200218029
HALİL İBRAHİM AYÇİÇEK 200218003


![Screenshot_2023-03-10-23-37-55-226_com example shop_app](https://user-images.githubusercontent.com/127450087/224440151-8aa1739f-9e62-4eec-be04-684cf1d6fb6e.jpg)
![Screenshot_2023-03-10-23-38-02-836_com example shop_app](https://user-images.githubusercontent.com/127450087/224440170-44df7166-c26f-4448-83d7-4f828a433b0e.jpg)
![Screenshot_2023-03-10-23-38-05-864_com example shop_app](https://user-images.githubusercontent.com/127450087/224440183-cea2ba88-3ca9-4e44-b770-4b8fed7c6a88.jpg)
![Screenshot_2023-03-10-23-38-18-614_com example shop_app](https://user-images.githubusercontent.com/127450087/224440196-67ed3b95-f83a-4354-b278-3bad190f6a2d.jpg)
![Screenshot_2023-03-10-23-39-02-921_com example shop_app](https://user-images.githubusercontent.com/127450087/224440266-39767294-4087-476f-834c-0050c10b8064.jpg)

![Screenshot_2023-03-10-23-38-36-633_com example shop_app](https://user-images.githubusercontent.com/127450087/224440220-327f587e-fb36-43a9-b5ab-5a3167cb436a.jpg)

![Screenshot_2023-03-10-23-38-56-170_com example shop_app](https://user-images.githubusercontent.com/127450087/224440254-fef4e787-3677-4e77-ad9a-b24bdfb13f21.jpg)


![Screenshot_2023-03-10-23-38-46-784_com example shop_app](https://user-images.githubusercontent.com/127450087/224440543-1a8645ca-0ab5-4f1a-b96e-45a7ec74371d.jpg)
